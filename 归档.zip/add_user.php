<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $qq_number = $_POST['qq_number'];
    $serial_number = $_POST['serial_number'];

    $sql = "INSERT INTO users (qq_number, serial_number) VALUES (:qq_number, :serial_number)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':qq_number', $qq_number);
    $stmt->bindParam(':serial_number', $serial_number);
    $stmt->execute();

    header("Location: index.html");
    exit();
}
?>
